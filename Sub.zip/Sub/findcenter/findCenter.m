%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xc, ratio] = findCenter(U, X, sigma)
% find the reflected center of the vector U, where the vector X specifies
% the sample locations
%
% ASSUMPTION
%   We assume that U contains the full shape of the signal, i.e., no
%   significant energy is truncated. Therefore, the center cannot locate
%   close to the endpoints.
%
% We use a multi-dimensional algorithm
%

U = U(:);
X = X(:);
eps = 1 / (length(X) * 20);     
                % normalized error tolerance (in respect of total range)

nSteps = 20;    % number of steps for each resloution stage
mSteps = 50;    % number of steps for the integral
mLargest = 5;   % Each stage, find mLargest points to narrow the search space

margin = 0.2;   % we may not have enough data to search outside the margin

if nargin < 3
    [~, sigma] = func_knnreg(0, U, X);  % determine the parameter using 
                                        % the cross-validation procedure
end

xRange = X(end) - X(1);
xLeft = X(1) + margin * xRange;
xRight = X(end) - margin * xRange;

Rmin = 1;
searchAreaValue = -1;
while (xRight - xLeft) > eps * xRange ...
        && abs((xLeft - X(1)) * xRange + (xRight - X(1)) - searchAreaValue) > 1e-9

    searchAreaValue = (xLeft - X(1)) * xRange + (xRight - X(1));
    
    tLeft = xLeft * 2;
    tRight = xRight * 2;
    
    Rc = zeros(1, nSteps);
    % T = tLeft: (tRight - tLeft) / (nSteps - 1) : tRight;
    T = tLeft + (0:nSteps - 1) * (tRight - tLeft) / (nSteps - 1); 
    
    for i = 1:nSteps
        t = T(i);
        
        % Note that it is not meaningful to calculate outside the area
        % (X(1), X(end), since the extrapolation is rough. Therefore, it is
        % better to restrict min < X < max, and min < - X + t < max
        intLeft = min(min(X), min(- X + t));
        intRight = max(max(X), max(- X + t));
        Xs = intLeft: (intRight - intLeft) / (mSteps - 1) : intRight;
        
        u1 = func_knnreg(Xs, U, X, sigma);
        u2 = func_knnreg(- Xs + t, U, X, sigma);
        
        Rc(i) = sum(u1 .* u2) / (norm(u1) * norm(u2));
        
    end
    [Rc_sorted, I] = sort(Rc, 'descend');
    tlarge = T(I(1:mLargest));
    tmin = min(tlarge);
    tmax = max(tlarge);
    
    xLeft = tmin / 2;
    xRight = tmax / 2;

    if Rc_sorted(end) < Rmin
        Rmin = Rc_sorted(end);
    end
    
    Rmax = Rc_sorted(1);
    
end

tpeak = T(I(1));
xc = tpeak / 2;

ratio = Rmax / Rmin;   % The ratio quantifies significance of the symmetry

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function xc = findCenter_cubic(U,X)
% find the reflected center of the vector U, where the vector X specifies
% the sample locations
%
% ASSUMPTION
%   We assume that U contains the full shape of the signal, i.e., no
%   significant energy is truncated. Therefore, the center cannot locate
%   close to the endpoints.
%
% We use a multi-dimensional algorithm
%

U = U(:);
X = X(:);
x = linspace(-1, 1, 100);
s = pchip(X,U,x); 
[~,idx]=max(s);
figure,
plot(X,U,'d-','LineWidth', 2, 'MarkerSize', 9)
hold on
plot(x,s,'LineWidth', 2, 'MarkerSize', 9)
xc=x(idx);

end

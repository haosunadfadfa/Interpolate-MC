%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function xc = findCenter_polyfit(U,X)
% find the reflected center of the vector U, where the vector X specifies
% the sample locations
%
% ASSUMPTION
%   We assume that U contains the full shape of the signal, i.e., no
%   significant energy is truncated. Therefore, the center cannot locate
%   close to the endpoints.
%
% We use a multi-dimensional algorithm
%

U = U(:);
X = X(:);

p = polyfit(X,U,4);
x = linspace(-1, 1, 400);
y = polyval(p,x);
% 
figure,
plot(X,U,'d-','LineWidth', 2, 'MarkerSize', 9)
hold on
plot(x,y,'LineWidth', 2, 'MarkerSize', 9)
[M,I] = max(y);
xc=x(I);

end

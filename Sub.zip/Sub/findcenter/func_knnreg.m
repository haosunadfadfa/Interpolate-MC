
function [f, sigma_out] = func_knnreg(x, U, X, sigma_in)
% f = func_knnreg(x, U, X, sigma)
% One-dimensional regression function based on kNN. Gaussian kernel
% weighted.
% 
% INPUT
%   x       scalar, the arguement of the regression funciton
%   U       a vector of discrete-sampled values
%   X       a vector of the corresponding locations (sorted in ascending
%           order)
%   sigma   the parameter for the kernel. If this argument is omitted, then
%           a cross-validation is run to choose the best sigma.
% 
% OUTPUT
%   f       the output value evaluted at position x
%
% Remark: Perhaps we need to run a pre-validation procedure to choose the
% right parameters (e.g., for the kernel)

U = U(:);
X = X(:);

if nargin < 4
    n0 = length(U);
    % sigmas = 0.8 .^ (1:30);
    sigmas = 0.01:0.01:0.5;
    
    n_randomization = 20;
    
    Errs = zeros(n_randomization, length(sigmas));
    for j = 1:n_randomization
        for i = 1:length(sigmas)
            rand_loc = randperm(n0);
            m0 = round(n0 * 0.7);
            train_loc = sort(rand_loc(1:m0), 'ascend');
            % test_loc = rand_loc(m0 + 1 : end);
            sigma = sigmas(i);
  %         f_test = func_knnreg(Xs_vec(test_loc), u_sample(train_loc), Xs_vec(train_loc), sigma);
  %         Errs(j, i) = sum((f_test  - u_sample(test_loc)).^2) / length(test_loc);

            f_test = func_knnreg(X, U(train_loc), X(train_loc), sigma);
            Errs(j, i) = sum((f_test  - U).^2) / length(f_test);

        end
    end
    errs = mean(Errs, 1);
    [~, I] = min(errs);
    sigma = sigmas(I);
else
    sigma = sigma_in;
end
width = 3 * sigma;  % The (single-side) width of the window of kernel weighted kNN

N = length(x(:));
f = zeros(size(x));

for i = 1:N
    x0 = x(i);
    x1 = x0 - width;
    x2 = x0 + width;

    c1 = find(x1 < X(:), 1);
    if isempty(c1)
        c1 = length(X(:));
    end
    c2 = find(x2 < X(:), 1);
    if isempty(c2)
        c2 = length(X(:));
    end
    
    weights = exp(- (x0 - X(c1:c2)) .^ 2 / (2 * sigma^2)) / (sqrt(2 * pi) * sigma);
    if abs(sum(weights)) < 1e-9
        f(i) = mean(U(c1:c2));
    else
        f(i) = sum(U(c1:c2) .* weights) / sum(weights);
    end
end

sigma_out = sigma;

end


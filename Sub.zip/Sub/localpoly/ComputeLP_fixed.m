function [yhat_eval,beta_eval,KW,W] = ComputeLP_fixed(X,y,h,kernel,X_eval,p)
%% Initial check
n = size(y,1);
m = size(X_eval,1);
% size returns a vector of length 2 with height and width of x
d = size(X,2); 
% Reassign d with the value of d(2) makes d a scalar with the value indicating the 
% number of input variables
%% Define kernel function
if strcmp(kernel,'gaussian'),
    %Gaussian kernel
    kerf = @(z) exp(-z.*z/2)/sqrt(2*pi);

elseif strcmp(kernel,'uniform'),
    %Uniform kernel
    kerf = @(z) 1/2*(abs(z)<=1);
 %    kerf = @(z) 70/81*(1-abs(z.^3)).*(abs(z)<=1);
    kerf = @(z) 3/4*(1-(0.6*z).^2).*(abs(z)<=1);

elseif strcmp(kernel,'epanechnikov'),
    %Epanechnikov kernel
    kerf = @(z) 3/4*(1-(z).^2).*(abs(z)<=1);

end


%% Local Linear Estimates on Evaluation points
num_estimates = 0;
for l = 0:p 
    num_estimates = num_estimates + factorial(d+l-1)/(factorial(d-1)*factorial(l));
end
prod_k = ones(m,n);

for kk = 1:d,
    prod_k = prod_k .* kerf((repmat(X(:,kk)',m,1) - repmat(X_eval(:,kk),1,n))./h(kk));
end

yhat_eval = zeros(m,1);
beta_eval = zeros(m,num_estimates-1);
error2 = zeros(m,1);
for i = 1:m

    W = zeros(n, num_estimates);
    W(:,1) = ones(n,1);
    curr_col = 2;
    for l = 1:p
        comb = nmultichoosek(1:d,l);
        for ll = 1:length(comb)
            W(:,curr_col) = prod( X(:,comb(ll,:)) - repmat(X_eval(i,comb(ll,:)),n,1), 2);
            curr_col = curr_col + 1;
        end
    end
    KW=spdiags(prod_k(i,:)',0,n,n);
    A = W' * spdiags(prod_k(i,:)',0,n,n) * W;
    B = W' * spdiags(prod_k(i,:)',0,n,n) * y;

    while rcond(A) < 1e-12
        A = A + eye(num_estimates,num_estimates).*(1/n);
    end
    temp_est = A\B;
    yhat_eval(i,:) = temp_est(1);
    beta_eval(i,:) = temp_est(2:end)';
end   


end
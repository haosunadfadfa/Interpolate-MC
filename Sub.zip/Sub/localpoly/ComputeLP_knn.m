function [yhat_eval,beta_eval] = ComputeLP_knn(X,y,KNN,kernel,X_tilde,X_eval,X_eval_tilde,p)


%% Initial check
n = size(y,1);
m = size(X_eval,1);
% size returns a vector of length 2 with height and width of x
d = size(X,2); 
% Reassign d with the value of d(2) makes d a scalar with the value indicating the 
% number of input variables



%% Define kernel function
if strcmp(kernel,'gaussian'),
    %Gaussian kernel
    kerf = @(z) exp(-z.*z/2)/sqrt(2*pi);

elseif strcmp(kernel,'uniform'),
    %Uniform kernel
    kerf = @(z) 1/2*(abs(z)<=1);

elseif strcmp(kernel,'epanechnikov'),
    %Epanechnikov kernel
    kerf = @(z) 3/4*(1-z^2)*(abs(z)<=1);
end




%% Local Linear Estimates on Evaluation points
num_estimates = 0;
for l = 0:p 
    num_estimates = num_estimates + factorial(d+l-1)/(factorial(d-1)*factorial(l));
end

Dist = ones(m,n);

for kk = 1:d,
    Dist = Dist + (repmat(X_tilde(:,kk)',m,1) - repmat(X_eval_tilde(:,kk),1,n)).^2;
end

R = zeros(m,1);

for i = 1:m,

    SortDist = sort(Dist(i,:));
    SortDistRev = unique(nonzeros(SortDist));

    if KNN < 1,
        R(i) = SortDistRev(2);
    elseif KNN > length(SortDistRev),
        R(i) = SortDistRev(length(SortDistRev));
    else
        R(i) = SortDistRev(KNN);
    end
end


prod_k = ones(m,n);
for i = 1:m
    for j = 1:n
        prod_k(i,j) = kerf(Dist(i,j)/R(i));
    end
end

yhat_eval = zeros(m,1);
beta_eval = zeros(m,num_estimates-1);
for i = 1:m
    
    W = zeros(n, num_estimates);
    W(:,1) = ones(n,1);
    curr_col = 2;
    for l = 1:p
        comb = nmultichoosek(1:d,l);
        for ll = 1:length(comb)
            W(:,curr_col) = prod( X(:,comb(ll,:)) - repmat(X_eval(i,comb(ll,:)),n,1), 2);
            curr_col = curr_col + 1;
        end
    end
    
    A = W' * spdiags(prod_k(i,:)',0,n,n) * W;
    B = W' * spdiags(prod_k(i,:)',0,n,n) * y;
    
    while rcond(A) < 1e-12
        A = A + eye(num_estimates,num_estimates).*(1/n);
    end

    temp_est = A\B;
    yhat_eval(i,:) = temp_est(1);
    beta_eval(i,:) = temp_est(2:end)';
end    


end
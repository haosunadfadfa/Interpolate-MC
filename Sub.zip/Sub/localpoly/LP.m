%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The code was written by Daisuke Yagi (d.yagi@tamu.edu).
% This is the function of Local Linear Kernel with Leave-one-out cross
% validation for the bandwidth selection.
%
%
% Input arguments:
%       X:              observed input (can be multiple columns)
%       y:              observed output (have to be single column)
%       p:              order of polynomial (e.g. 0: Local Constant, 1: Local Linear, 2: Local Quadratic...)
%       type_bandwidth: type of bandwidth ('fixed','variable')
%                       where I use KNN for variable bandwidth
%       kernel:         type of kernel ('gaussian','uniform','epanechnikov')
%       X_eval:         evaluation point (input space) where you want to get estimates
%                       if this is empty, X_eval := X
%
% Output arguments:
%       yhat_eval:      functional estimate on each grid points
%       beta_eval:      estimates of partial derivative
%
% For more information, please read the paper (http://~).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [yhat_eval,beta_eval,KW,W] = LP(X,y,p,type_bandwidth,kernel,bandwidth,X_eval)


%% Error check
n = size(X,1);
d = size(X,2);


switch nargin,
    case [0,1],
        error('Not enough arguments.')
    case 2,
        p = 1;
        type_bandwidth = 'fixed';
        kernel = 'gaussian';
        bandwidth = std(X)*n^(-1/(4+d));
        X_eval = X;    
    case 3,
        kernel = 'gaussian';
        if strcmp(type_bandwidth,'fixed'),
            bandwidth = std(X)*n^(-1/(4+d)); 
        elseif strcmp(type_bandwidth,'variable'),
            bandwidth = round(n/10);
        end
        X_eval = X;
    case 4,
        if strcmp(type_bandwidth,'fixed'),
            bandwidth = std(X)*n^(-1/(4+d)); 
        elseif strcmp(type_bandwidth,'variable'),
            bandwidth = round(n/10);
        end
        X_eval = X;
    case 5,
        if strcmp(type_bandwidth,'fixed'),
            bandwidth = std(X)*n^(-1/(4+d)); 
        elseif strcmp(type_bandwidth,'variable'),
            bandwidth = round(n/10);
        end
        X_eval = X;
    case 6,
        X_eval = X;
end

if strcmp(type_bandwidth,'fixed') + strcmp(type_bandwidth,'variable') == 0,
    error('"type_bandwidth" has wrong name. Choose "fixed" or "variable".')
end
if strcmp(kernel,'gaussian') + strcmp(kernel,'uniform') + strcmp(kernel,'epanechnikov') == 0,
    error('"kernel" has wrong name. Choose "gaussian", "uniform" or "epanechnikov".') 
end

m = size(X_eval,1);



%% Compute each matrix needed for Quadratic Programming
if strcmp(type_bandwidth,'fixed'),
    [yhat_eval,beta_eval,KW,W] = ComputeLP_fixed(X,y,bandwidth,kernel,X_eval,p);
elseif strcmp(type_bandwidth,'variable'),
    X_tilde = (X-repmat(mean(X),size(X,1),1))./repmat(std(X),size(X,1),1);
    X_eval_tilde=(X_eval-repmat(mean(X),size(X_eval,1),1))./repmat(std(X),size(X_eval,1),1);
    [yhat_eval,beta_eval] = ComputeLP_knn(X,y,bandwidth,kernel,X_tilde,X_eval,X_eval_tilde,p);
end


end
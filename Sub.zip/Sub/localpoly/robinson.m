%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The code was written by Daisuke Yagi (d.yagi@tamu.edu).
% This is the function of Robinson estimator to obtain the linear
% parameters for partial linear model.
%
%
% Input arguments:
%       X:              observed input - unknown functional form (can be multiple columns)
%       y:              observed output (have to be single column)
%       Z:              observed input - linear functional form (can be multiple columns)
%       p:              order of polynomial (e.g. 0: Local Constant, 1: Local Linear, 2: Local Quadratic...)
%       type_bandwidth: type of bandwidth ('fixed','variable')
%                       where I use KNN for variable bandwidth
%       kernel:         type of kernel ('gaussian','uniform','epanechnikov')
%       selection:      bandwidth selection method.
%       alpha:          significance level to obtain confidence interval
%
%
% Output arguments:
%       gamma_hat:      coefficient estimates for linear parameters
%       p_value:        p-value for t-test
%       CI:             confidence interval of gamma_hat
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [gamma_hat, p_gamma, CI_gamma, model1] = robinson(X,y,Z,p,type_bandwidth,kernel,selection,alpha)


%% Error check
n = size(X,1);
d = size(X,2);


switch nargin,
    case [0,1,2],
        error('Not enough arguments.')
    case 3,
        p = 1;
        type_bandwidth = 'fixed';
        kernel = 'gaussian';
        selection = 'Rule-of-Thumb';
        alpha = 0.05; 
    case 4,
        type_bandwidth = 'fixed';
        kernel = 'gaussian';
        selection = 'Rule-of-Thumb';
        alpha = 0.05; 
    case 5,
        kernel = 'gaussian';
        selection = 'Rule-of-Thumb';
        alpha = 0.05; 
    case 6,
        selection = 'Rule-of-Thumb';
        alpha = 0.05; 
    case 7,
        alpha = 0.05; 
end

if strcmp(type_bandwidth,'fixed') + strcmp(type_bandwidth,'variable') == 0,
    error('"type_bandwidth" has wrong name. Choose "fixed" or "variable".')
end
if strcmp(kernel,'gaussian') + strcmp(kernel,'uniform') + strcmp(kernel,'epanechnikov') == 0,
    error('"kernel" has wrong name. Choose "gaussian", "uniform" or "epanechnikov".') 
end


%% Bandwidth selection for fixed and variable bandwidth

if strcmp(type_bandwidth,'fixed')
    BD1 = BandwidthFixed(X,y,'gaussian',selection);
    BD2 = zeros(size(Z,2),d);
    for dd = 1:size(Z,2)
        BD2(dd,:) = BandwidthFixed(X,Z(:,dd),'gaussian',selection);
    end
elseif strcmp(type_bandwidth,'variable')
    BD1 = BandwidthKNN(X,y,'gaussian',selection);
    BD2 = zeros(size(Z,2),1);
    for dd = 1:size(Z,2)
        BD2(dd,1) = BandwidthKNN(X,Z(:,dd),'gaussian',selection);
    end
end


%% Compute conditional expectation
y_given_X = LP(X,y,p,type_bandwidth,kernel,BD1);
Z_given_X = zeros(n,size(Z,2));
for dd = 1:size(Z,2),
    Z_given_X(:,dd) = LP(X,Z(:,dd),p,type_bandwidth,kernel,BD2(dd,:));
end


%% Compoute OLS
y_tilde = y - y_given_X;
Z_tilde = Z - Z_given_X;   
ZZ = Z_tilde'*Z_tilde;
while rcond(ZZ) < 1e-12
    ZZ = ZZ + eye(size(ZZ,1),size(ZZ,2)).*(1/length(y));
end
gamma_hat = ZZ\(Z_tilde'*y_tilde);
model1 = fitlm(Z_tilde,y_tilde,'Intercept',false);        


CI_gamma = coefCI(model1,alpha);
p_gamma = model1.Coefficients.pValue;



end
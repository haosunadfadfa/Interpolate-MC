% gstat_examples

figure(3);ex03;
figure(4);ex04;
figure(5);ex05;
figure(6);ex06;
figure(7);ex07;
%figure(8);ex08;
figure(9);ex09;
figure(10);ex10;



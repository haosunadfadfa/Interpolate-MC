% mgstat_clean : clean up temporary files from visim, sgems

visim_clean;
sgems_clean;

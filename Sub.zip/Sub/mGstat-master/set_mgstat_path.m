mgstat_path=fileparts(which('mGstat'));
addpath(sprintf('%s/visim/',mgstat_path));
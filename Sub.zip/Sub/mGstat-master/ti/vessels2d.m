% vessels2d : 2D [456x433] training image
% from From Dirk-Jan Kroon's fast marching toolbox
function d=vessels2d;
d=load('vessels2d.mat');
d=d.vessels2d;

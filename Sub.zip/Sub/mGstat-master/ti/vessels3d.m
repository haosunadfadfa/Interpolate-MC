% vessels2d : 3D [256x256x256] training image
% from From Dirk-Jan Kroon's fast marching toolbox
function d=vessels3d;
d=load('vessels3d.mat');
d=d.vessels3d;

function [Xc,A] = myMatComplt(n, m, sample_index, observed_data, noise)

if nargin < 5
    noise = 0;
end

nSamples = length(sample_index);

A = zeros(nSamples, n * m);
for i = 1:nSamples
    A(i, sample_index(i)) = 1;
end
b = observed_data(:);
b1 = b - noise .* ones(size(b));
b2 = b + noise .* ones(size(b));

% tic
cvx_begin quiet
    variable Xc(n, m)
    minimize ( norm_nuc(Xc) )
    subject to
        A * Xc(:) >= b1
        A * Xc(:) <= b2
cvx_end
% toc

end




function [S1,S2,S3,S4,Hc0,bias,var,mse,LPR,H0,error_cpr,error_cpr2] = slumf_0th_findcenter...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,h,LH,delta)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end

% SPARSE Matrix observation model
H0 = zeros(n);
LPR = zeros(n);
% error_cpr2 = zeros(n);
error_cpr = zeros(n);
% h = BandwidthFixed(Z,hZ',kernel,h_select,0);
bias = zeros(n);
var = zeros(n);
mse = 0;
for m = 1:M
    i = floor((Z(m, 1) + LH / 2) / (LH / n)) + 1;
    j = floor((Z(m, 2) + LH / 2) / (LH / n)) + 1;
    if i > 0 && j > 0 && i <= n && j<=n 
        H0(i, j) = hZ(m);
    end
    [LPR(i,j),~,~,KW,W] = LP(Z,hZ',0,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    [~,beta] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    A = W' * KW * W;
    E = inv(A)*W'*(KW*(Z-[Gxinitial(i) Gyinitial(j)]))*(beta');
    V = inv(A)*W'*(KW.*KW)*W*inv(A)*std_ambient_noise^2; 
    error_cpr(i,j) = delta*sqrt(V);
    LPR(i,j)=LPR(i,j)-E;
    bias = abs(E)+bias;
    var = var+V;
    mse = mse + E^2 + V;
end

sample_index = find(H0 > 0);
Hc0 = myMatComplt(n, n, sample_index, LPR(sample_index), error_cpr(sample_index));

% Source localization via SVD -> reflective correlation estimator
[vecL, ~, vecR] = svds(Hc0, 1);
if sum(vecL) < 0
    vecL = - vecL;
end
if sum(vecR) < 0
    vecR = - vecR;
end

% x_hat = findCenter(vecL, Gxinitial);
% % y_hat = findCenter(vecR, Gyinitial);
% x_hat = findCenter_polyfit(vecL, Gxinitial);
% y_hat = findCenter_polyfit(vecR, Gyinitial);
% x_hat = findCenter_cubic(vecL, Gxinitial);
% y_hat = findCenter_cubic(vecR, Gyinitial);
x_hat1 = findCenter(vecL, Gxinitial);
y_hat1 = findCenter(vecR, Gyinitial);
x_hat2 = findCenter_polyfit(vecL, Gxinitial);
y_hat2 = findCenter_polyfit(vecR, Gyinitial);
x_hat3 = findCenter_cubic(vecL, Gxinitial);
y_hat3 = findCenter_cubic(vecR, Gyinitial);
x_hat4 = findCenter_localpolyfit(vecL, Gxinitial);
y_hat4 = findCenter_localpolyfit(vecR, Gyinitial);
S1 = [x_hat1, y_hat1];
S2 = [x_hat2, y_hat2];
S3 = [x_hat3, y_hat3];
S4 = [x_hat4, y_hat4];

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



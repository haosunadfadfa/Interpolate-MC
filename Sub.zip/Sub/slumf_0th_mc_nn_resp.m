function [Hc0,mse_c] = slumf_0th_mc_nn_resp...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,h,LH,delta)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end

LPR = zeros(n);
error_cpr = zeros(n);
mse = 0;
mse_c = 0;
mse_cv = 0; %cross validation
count=0;
for i = 1:n
    for j=1:n
    [~,D] = knnsearch(Z,[Gxinitial(i) Gyinitial(j)],'K',3);
    if D(end)>h
        continue
    end
    [LPR(i,j),~,KW,W] = LP(Z,hZ',0,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    [~,beta] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    A = W' * KW * W;
    E = inv(A)*W'*KW*((Z-[Gxinitial(i) Gyinitial(j)])*beta');
    V = inv(A)*W'*(KW.*KW)*W*inv(A)*std_ambient_noise^2; 
    error_cpr(i,j) = delta*sqrt(V);
    LPR(i,j) = LPR(i,j)-E;
    mse_c = mse_c + E^2 + V;
    
%     Znew = Z;
%     Zm=Z(m,:);
%     Znew(m,:)=[];
%     hZnew=hZ;
%     hZnew(:,m)=[];
%     [CR,~,KW,W] = LP(Znew,hZnew',0,type_h,kernel,h,Zm);
%     [~,beta] = LP(Znew,hZnew',1,type_h,kernel,h+[0.2 0.2],Zm);
%     A = W' * KW * W;
%     if isequal(A,0)
%         continue;
%     end
%     count=count+1;
% 
%     E = inv(A)*W'*KW*((Znew-Zm)*beta');
%     V = inv(A)*W'*(KW.*KW)*W*inv(A)*std_ambient_noise^2;
%  
%     mse = mse + E^2 + V;
%     mse = mse/count;
%     mse_cv = mse_cv + norm(CR-hZ(:,m))^2;
%     mse_cv = mse_cv/count;
    end
end
mse_c = mse_c/length(find(LPR));
% Matrix completion
sample_index = find(LPR > 0);
Hc0 = myMatComplt(n, n, sample_index, LPR(sample_index), error_cpr(sample_index));

% Source localization via SVD -> reflective correlation estimator
[vecL, ~, vecR] = svds(Hc0, 1);
if sum(vecL) < 0
    vecL = - vecL;
end
if sum(vecR) < 0
    vecR = - vecR;
end

% x_hat = findCenter(vecL, Gxinitial);
% y_hat = findCenter(vecR, Gyinitial);
% x_hat = findCenter_polyfit(vecL, Gxinitial);
% y_hat = findCenter_polyfit(vecR, Gyinitial);
% x_hat = findCenter_cubic(vecL, Gxinitial);
% y_hat = findCenter_cubic(vecR, Gyinitial);
x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



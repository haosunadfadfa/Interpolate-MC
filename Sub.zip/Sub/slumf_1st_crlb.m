function [S,Hc0,variance,A] = slumf_1st_crlb...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,h,LH,delta)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end

% SPARSE Matrix observation model
H0 = zeros(n);
LPR = zeros(n);

error_cpr= zeros(n);
% h = BandwidthFixed(Z,hZ',kernel,h_select,1);
bias = 0;
variance = zeros(n);
quad = zeros(M,1);

mse = 0;
for m = 1:M
    i = floor((Z(m, 1) + LH / 2) / (LH / n)) + 1;
    j = floor((Z(m, 2) + LH / 2) / (LH / n)) + 1;
  
    if i > 0 && j > 0 && i <= n && j <= n
        H0(i, j) = hZ(m);
    end
    [LPR(i,j),~,KW,W] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    [~,beta] = LP(Z,hZ',2,type_h,kernel,h+[0.3 0.3],[Gxinitial(i) Gyinitial(j)]);
    KK = W' * KW * W;
    for ii=1: M
       quad(ii)=(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])*([beta(3) beta(4);beta(4) beta(5)])*(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])';
    end
    E = [1 0 0]*inv(KK)*W'*KW*0.5*quad;
    V = [1 0 0]*inv(KK)*W'*(KW.*KW)*W*inv(KK)*[1 0 0]'*std_ambient_noise^2;
    error_cpr(i,j) = delta*sqrt(V);
    LPR(i,j)=LPR(i,j)-E;
%     bias = E^2+bias;
    variance(i,j) = V;
%     mse = mse + E^2 + V;
end

% Matrix completion
sample_index = find(H0 > 0);

variance=variance(sample_index);
[Hc0,A] = myMatComplt(n, n, sample_index, LPR(sample_index), error_cpr(sample_index));

% Source localization via SVD -> reflective correlation estimator
[vecL, ~, vecR] = svds(Hc0, 1);
if sum(vecL) < 0
    vecL = - vecL;
end
if sum(vecR) < 0
    vecR = - vecR;
end

% x_hat = findCenter(vecL, Gxinitial);
% y_hat = findCenter(vecR, Gyinitial);
% x_hat = findCenter_polyfit(vecL, Gxinitial);
% y_hat = findCenter_polyfit(vecR, Gyinitial);
% x_hat = findCenter_cubic(vecL, Gxinitial);
% y_hat = findCenter_cubic(vecR, Gyinitial);
x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




function [S, LPR] = slumf_1st_estimate_all_nn...
    (Z, hZ,n,Gxinitial,Gyinitial,type_h,kernel,h)

loc=[reshape(repmat(Gxinitial,1,n),n*n,1) reshape(repmat(Gyinitial,1,n)',n*n,1)];
[LPR] = LP(Z,hZ',1,type_h,kernel,h,loc);

LPR=reshape(LPR,n,n);
[vecL, ~, vecR] = svds(LPR, 1);
if sum(vecL) < 0
    vecL = - vecL;
end
if sum(vecR) < 0
    vecR = - vecR;
end

% x_hat = findCenter(vecL, Gxinitial);
% y_hat = findCenter(vecR, Gyinitial);
% x_hat = findCenter_polyfit(vecL, Gxinitial);
% y_hat = findCenter_polyfit(vecR, Gyinitial);
% x_hat = findCenter_cubic(vecL, Gxinitial);
% y_hat = findCenter_cubic(vecR, Gyinitial);
x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



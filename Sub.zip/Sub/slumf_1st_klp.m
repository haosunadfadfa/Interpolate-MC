function [LPR] = slumf_1st_klp(Z,hZ,n,Gxinitial,Gyinitial,M)

M=length(hZ);
loc=[reshape(repmat(Gxinitial,1,n),n*n,1) reshape(repmat(Gyinitial,1,n)',n*n,1)];
hlpr_1=14;hlpr_2=40;b_lpr=1;
mse = zeros(round(hlpr_2-hlpr_1)/b_lpr+1,1);
sr = 0.95;

for h=hlpr_1:b_lpr:hlpr_2
    params = lwpparams('EPA', 1, true,h);
    
    [LPR] = lwppredict(Z(1:sr*M,:),hZ(1:sr*M)',params,Z(sr*M+1:M,:));
    mse(round(h-hlpr_1)/b_lpr+1) = norm(LPR-hZ(sr*M+1:M));
end
[~,idx] = min(mse);
h= (idx-1)*b_lpr+hlpr_1;
params = lwpparams('EPA', 1, true,h);

[LPR] = lwppredict(Z,hZ',params,loc);

LPR=reshape(LPR,n,n);

end
function [LPR] = slumf_1st_klp_realdata...
    (Z, hZ,n,loca)

M=length(hZ);
% if M<n
%     h=0.9;
% else
%     h=n/M;
    h = 10;
% end
% loc=[reshape(repmat(Gxinitial,1,n),n*n,1) reshape(repmat(Gyinitial,1,n)',n*n,1)];
params = lwpparams('EPA', 1, true,h);

[LPR] = lwppredict(Z,hZ,params,loca);

LPR=reshape(LPR,14,34)';
% [vecL, ~, vecR] = svds(LPR, 1);
% if sum(vecL) < 0
%     vecL = - vecL;
% end
% if sum(vecR) < 0
%     vecR = - vecR;
% end
% 
% % x_hat = findCenter(vecL, Gxinitial);
% % y_hat = findCenter(vecR, Gyinitial);
% % x_hat = findCenter_polyfit(vecL, Gxinitial);
% % y_hat = findCenter_polyfit(vecR, Gyinitial);
% % x_hat = findCenter_cubic(vecL, Gxinitial);
% % y_hat = findCenter_cubic(vecR, Gyinitial);
% x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
% y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
% S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



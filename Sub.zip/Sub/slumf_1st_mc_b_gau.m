%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0,LPR] = slumf_1st_mc_b_gau...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,delta,h1,h2,bb)
% bb=0.02;
M = length(hZ);
lpr = cell(round((h2(1)-h1(1))/bb)+1,1);
error = cell(round((h2(1)-h1(1))/bb)+1,1);
MSE_c= zeros(round((h2(1)-h1(1))/bb)+1,1);

for hh=h1(1):bb:h2(1)
    h=[hh hh];
LPR = zeros(n);
quad=zeros(M,1);
error_cpr = zeros(n);
mse_c = 0;
for i = 1:n
    for j=1:n
        [~,D] = knnsearch(Z,[Gxinitial(i) Gyinitial(j)],'K',1);
        if D(end)>h(1)
            continue
        end
        [LPR(i,j),~,KW,W] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
        [~,beta] = LP(Z,hZ',2,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
        A = W' * KW * W;
        for iii=1: M
            quad(iii)=(Z(iii,:)-[Gxinitial(i) Gyinitial(j)])*([beta(3) beta(4);beta(4) beta(5)])*(Z(iii,:)-[Gxinitial(i) Gyinitial(j)])';
        end
        E = [1 0 0]*inv(A)*W'*KW*0.5*quad;
        V = [1 0 0]*inv(A)*W'*(KW.*KW)*W*inv(A)*[1 0 0]'*std_ambient_noise^2;
        error_cpr(i,j) = delta*sqrt(V);
        LPR(i,j) = LPR(i,j)-E;
        mse_c = mse_c + E^2 + V;
    end
end
lpr{round((hh-h1(1))/bb)+1}=LPR;
error{round((hh-h1(1))/bb)+1}=error_cpr;
% mse=mse/length(find(LPR));
MSE_c(round((hh-h1)/bb)+1) = mse_c/length(find(LPR));
end
[~,idx] = min(MSE_c);
H_0 = lpr{idx};
err = error{idx};
% h=[bb*(idx-1)+h1(1) bb*(idx-1)+h1(1)];
% Matrix completion
sample_index = find(H_0 > 0);
Hc0 = myMatComplt(n, n, sample_index, H_0(sample_index), err(sample_index));
% Source localization via SVD -> reflective correlation estimator
% [vecL, ~, vecR] = svds(Hc0, 1);
% if sum(vecL) < 0
%     vecL = - vecL;
% end
% if sum(vecR) < 0
%     vecR = - vecR;
% end
% 
% % x_hat = findCenter(vecL, Gxinitial);
% % y_hat = findCenter(vecR, Gyinitial);
% % x_hat = findCenter_polyfit(vecL, Gxinitial);
% % y_hat = findCenter_polyfit(vecR, Gyinitial);
% % x_hat = findCenter_cubic(vecL, Gxinitial);
% % y_hat = findCenter_cubic(vecR, Gyinitial);
% x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
% y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
% S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Xc,A] = myMatComplt(n, m, sample_index, observed_data, noise)

if nargin < 5
    noise = 0;
end

nSamples = length(sample_index);

A = zeros(nSamples, n * m);
for i = 1:nSamples
    A(i, sample_index(i)) = 1;
end
b = observed_data(:);
b1 = b - noise .* ones(size(b));
b2 = b + noise .* ones(size(b));

% tic
cvx_begin quiet
    variable Xc(n, m)
    minimize ( norm_nuc(Xc) )
    subject to
        A * Xc(:) >= b1
        A * Xc(:) <= b2
cvx_end
% toc

end







%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0,LPR_org] = slumf_1st_mc_bij_0_realdata...
    (Z, hZ,n1,n2,std_ambient_noise,type_h,kernel,delta,h1,h2,bb,loca)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end
LPR = zeros(n2,n1);
LPR_org = zeros(n2,n1);
error_cpr = zeros(n2,n1);
quad = zeros(M,1);

for i = 1:n2
    for j=1:n1
        [val,D] = knnsearch(Z,loca((i-1)*n1+j,:),'K',3);
    if D(end)>h2
        continue
    end
        for hh=h1(1):bb:h2(1)
            h=[hh hh];
             
                if D(end)>hh
                    MSE_c(round((hh-h1)/bb)+1) = NaN;
                    continue
                end
          [LPR_org(i,j),~,KW,W] = LP(Z,hZ,0,type_h,kernel,h,loca((i-1)*n1+j,:));
            [~,beta] = LP(Z,hZ,1,type_h,kernel,h,loca((i-1)*n1+j,:));
            A = W' * KW * W;
            E = inv(A)*W'*KW*((Z-loca((i-1)*n1+j,:))*beta');
            V = inv(A)*W'*(KW.*KW)*W*inv(A)*std_ambient_noise^2; 
            error_cpr(i,j) = delta*sqrt(V);
            LPR(i,j)=LPR_org(i,j)-E;;
        %     error_cpr(i,j) = delta*sqrt(V);
        %     LPR(i,j) = LPR(i,j)-E;
            mse_c = E^2 + V;
            MSE_c(round((hh-h1)/bb)+1) = mse_c;
        end
    [~,idx]=min(MSE_c);
    h=[bb*(idx-1)+h1(1) bb*(idx-1)+h1(1)];
    [LPR_org(i,j),~,KW,W] = LP(Z,hZ,0,type_h,kernel,h,loca((i-1)*n1+j,:));
    [~,beta] = LP(Z,hZ,1,type_h,kernel,h,loca((i-1)*n1+j,:));
    A = W' * KW * W;
    E = inv(A)*W'*KW*((Z-loca((i-1)*n1+j,:))*beta');
    V = inv(A)*W'*(KW.*KW)*W*inv(A)*std_ambient_noise^2; 
    error_cpr(i,j) = delta*sqrt(V);
    LPR(i,j)=LPR_org(i,j)-E;
    end
end

% Matrix completion
% Matrix completion
sample_index = find(LPR ~=0);
Hc0 = myMatComplt(n2, n1, sample_index, LPR(sample_index), error_cpr(sample_index));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




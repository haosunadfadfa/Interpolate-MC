%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0,LPR_org,count] = slumf_1st_mc_nn_bij_new...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,delta,h1,h2,bb)
% bb=0.02;
count = 0;
M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end
LPR = zeros(n);
LPR_org = zeros(n);
error_cpr= zeros(n);
quad = zeros(M,1);
for i = 1:n
    for j=1:n
%     [val,D] = knnsearch(Z,[Gxinitial(i) Gyinitial(j)],'K',6);
%     if D(end)>h2
%         continue
%     end
        for hh=h1(1):bb:h2(1)
            h=[hh hh];
             
%                 if D(end)>hh
%                     MSE_c(round((hh-h1)/bb)+1) = NaN;
%                     continue
%                 end
            quad=zeros(M,1);
            [LPR(i,j),~,KW,W] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
            [~,beta] = LP(Z,hZ',2,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
            A = W' * KW * W;
            for iii=1: M
                quad(iii)=(Z(iii,:)-[Gxinitial(i) Gyinitial(j)])*([beta(3) beta(4);beta(4) beta(5)])*(Z(iii,:)-[Gxinitial(i) Gyinitial(j)])';
            end
            E = [1 0 0]*inv(A)*W'*KW*0.5*quad;
            V = [1 0 0]*inv(A)*W'*(KW.*KW)*W*inv(A)*[1 0 0]'*std_ambient_noise^2;
        %     error_cpr(i,j) = delta*sqrt(V);
        %     LPR(i,j) = LPR(i,j)-E;
            mse_c = E^2 + V;
            MSE_c(round((hh-h1)/bb)+1) = mse_c;
        end
    [~,idx]=min(MSE_c);
    [val,D] = knnsearch(Z,[Gxinitial(i) Gyinitial(j)],'K',6);
    h=[bb*(idx-1)+h1(1) bb*(idx-1)+h1(1)];
    if D(end)>h
        continue
    end
    [LPR_org(i,j),~,KW,W] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    [~,beta] = LP(Z,hZ',2,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    A = W' * KW * W;
    for ii=1: M
       quad(ii)=(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])*([beta(3) beta(4);beta(4) beta(5)])*(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])';
    end
    E = [1 0 0]*inv(A)*W'*KW*0.5*quad;
    V = [1 0 0]*inv(A)*W'*(KW.*KW)*W*inv(A)*[1 0 0]'*std_ambient_noise^2;
    error_cpr(i,j) = real(delta*sqrt(V));
    LPR(i,j)=LPR_org(i,j)-E;
    count = count+1;
    end
end
% Matrix completion
sample_index = find(LPR > 0);
Hc0 = myMatComplt(n, n, sample_index, LPR(sample_index), error_cpr(sample_index));
% Source localization via SVD -> reflective correlation estimator
% [vecL, ~, vecR] = svds(Hc0, 1);
% if sum(vecL) < 0
%     vecL = - vecL;
% end
% if sum(vecR) < 0
%     vecR = - vecR;
% end
% 
% % x_hat = findCenter(vecL, Gxinitial);
% % y_hat = findCenter(vecR, Gyinitial);
% % x_hat = findCenter_polyfit(vecL, Gxinitial);
% % y_hat = findCenter_polyfit(vecR, Gyinitial);
% % x_hat = findCenter_cubic(vecL, Gxinitial);
% % y_hat = findCenter_cubic(vecR, Gyinitial);
% x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
% y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
% S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Xc,A] = myMatComplt(n, m, sample_index, observed_data, noise)

if nargin < 5
    noise = 0;
end

nSamples = length(sample_index);

A = zeros(nSamples, n * m);
for i = 1:nSamples
    A(i, sample_index(i)) = 1;
end
b = observed_data(:);
b1 = b - noise .* ones(size(b));
b2 = b + noise .* ones(size(b));

% tic
cvx_begin quiet
    variable Xc(n, m)
    minimize ( norm_nuc(Xc) )
    subject to
        A * Xc(:) >= b1
        A * Xc(:) <= b2
cvx_end
% toc

end







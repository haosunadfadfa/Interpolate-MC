%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
%we do not substract the bias.
function [S,Hc0,LPR_org] = slumf_1st_mc_nn_nosubtract_interval...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,h,LH,delta)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end
LPR = zeros(n);
LPR_org = zeros(n);

error = zeros(n);

error_left= zeros(n);
error_right= zeros(n);
quad = zeros(M,1);

for i = 1:n
    for j=1:n
    [~,D] = knnsearch(Z,[Gxinitial(i) Gyinitial(j)],'K',6);
    if D(end)>h
        continue
    end
    [LPR_org(i,j),~,KW,W] = LP(Z,hZ',1,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    [~,beta] = LP(Z,hZ',2,type_h,kernel,h,[Gxinitial(i) Gyinitial(j)]);
    A = W' * KW * W;
    for ii=1: M
       quad(ii)=(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])*([beta(3) beta(4);beta(4) beta(5)])*(Z(ii,:)-[Gxinitial(i) Gyinitial(j)])';
    end
    E = [1 0 0]*inv(A)*W'*KW*0.5*quad;
    V = [1 0 0]*inv(A)*W'*(KW.*KW)*W*inv(A)*[1 0 0]'*std_ambient_noise^2;
    error_left(i,j) = E - delta*sqrt(V);
    error_right(i,j) = E + delta*sqrt(V);
%     error(i,j) = max([abs(error_left(i,j)) abs(error_right(i,j))]);
    LPR(i,j)=LPR_org(i,j);
    end
end
% Matrix completion
sample_index = find(LPR > 0);
Hc0 = myMatComplt_NoiseInterval(n, n, sample_index, LPR(sample_index), error_left(sample_index),error_right(sample_index));
% Hc0 = myMatComplt(n, n, sample_index, LPR(sample_index), error(sample_index));

% Source localization via SVD -> reflective correlation estimator
[vecL, ~, vecR] = svds(Hc0, 1);
if sum(vecL) < 0
    vecL = - vecL;
end
if sum(vecR) < 0
    vecR = - vecR;
end

% x_hat = findCenter(vecL, Gxinitial);
% y_hat = findCenter(vecR, Gyinitial);
% x_hat = findCenter_polyfit(vecL, Gxinitial);
% y_hat = findCenter_polyfit(vecR, Gyinitial);
% x_hat = findCenter_cubic(vecL, Gxinitial);
% y_hat = findCenter_cubic(vecR, Gyinitial);
x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




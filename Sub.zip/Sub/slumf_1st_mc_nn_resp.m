%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0] = slumf_1st_mc_nn_resp(n,Gxinitial,Gyinitial,LPR,error_cpr)

sample_index = find(LPR > 0);
Hc0 = myMatComplt(n, n, sample_index, LPR(sample_index), error_cpr(sample_index));

% % Source localization via SVD -> reflective correlation estimator
% [vecL, ~, vecR] = svds(Hc0, 1);
% if sum(vecL) < 0
%     vecL = - vecL;
% end
% if sum(vecR) < 0
%     vecR = - vecR;
% end
% 
% % x_hat = findCenter(vecL, Gxinitial);
% % y_hat = findCenter(vecR, Gyinitial);
% % x_hat = findCenter_polyfit(vecL, Gxinitial);
% % y_hat = findCenter_polyfit(vecR, Gyinitial);
% % x_hat = findCenter_cubic(vecL, Gxinitial);
% % y_hat = findCenter_cubic(vecR, Gyinitial);
% x_hat = findCenter_localpolyfit(vecL, Gxinitial,n);
% y_hat = findCenter_localpolyfit(vecR, Gyinitial,n);
% S = [x_hat, y_hat];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




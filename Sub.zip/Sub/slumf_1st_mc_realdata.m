%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0,LPR_org] = slumf_1st_mc_realdata...
    (Z, hZ,n1,n2,std_ambient_noise,type_h,kernel,h,delta,loca,Hc1)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end
LPR = zeros(n2,n1);
LPR_org = zeros(n2,n1);
error_cpr = zeros(n2,n1);
quad = zeros(M,1);

for i = 1:n2
    for j=1:n1
    [~,D] = knnsearch(Z,loca((i-1)*n1+j,:),'K',6);
    if D(end)>h
        continue
    end
    [LPR_org(i,j),~,KW,W] = LP(Z,hZ,1,type_h,kernel,h,loca((i-1)*n1+j,:));
    [~,beta] = LP(Z,hZ,2,type_h,kernel,h,loca((i-1)*n1+j,:));
    A = W' * KW * W;
    for ii=1: M
       quad(ii)=(Z(ii,:)-loca((i-1)*n1+j,:))*([beta(3) beta(4);beta(4) beta(5)])...
           *(Z(ii,:)-loca((i-1)*n1+j,:))';
    end
    E = [1 0 0]*inv(A)*W'*KW*0.5*quad;
    V = [1 0 0]*inv(A)*W'*(KW.*KW)*W*inv(A)*[1 0 0]'*std_ambient_noise^2;
    
    error_cpr(i,j) = delta*sqrt(V);
    LPR(i,j)=LPR_org(i,j)-E;
    end
end
% Matrix completion
sample = find(Hc1);
LPR(sample) = Hc1(sample);
error_cpr(sample)=0;
sample_index = find(LPR ~=0);
Hc0 = myMatComplt(n2, n1, sample_index, LPR(sample_index), error_cpr(sample_index));
% Hc0 = Hc0';%reshape(Hc0,34,14);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0,LPR_org] = slumf_1st_mc_realdata_new...
    (n1,n2,LPR,error_cpr,Hc1)

sample = find(Hc1);
LPR(sample) = Hc1(sample);
error_cpr(sample)=0;

sample_index = find(LPR ~=0);
Hc0 = myMatComplt(n2, n1, sample_index, LPR(sample_index), error_cpr(sample_index));
% Hc0 = Hc0';%reshape(Hc0,34,14);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




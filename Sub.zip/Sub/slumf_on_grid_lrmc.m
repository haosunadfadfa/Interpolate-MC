%THIS use 1st order regression assisted matrix completion with only select
%those grids have several sensors around
function [Hc0] = slumf_on_grid_lrmc...
    (Z, hZ,n,std_ambient_noise,Gxinitial,Gyinitial,type_h,kernel,LH,delta,H_u)

M = length(hZ);
if size(Z, 1) ~= M
    error('Dimension mismatch!');
end

% SPARSE Matrix observation model
H0 = zeros(n);
ClosestDistanceThisEntry=zeros(n);
for m = 1:M
    i = floor((Z(m, 1) + LH / 2) / (LH / n)) + 1;
    j = floor((Z(m, 2) + LH / 2) / (LH / n)) + 1;
%      if i > 0 && j > 0 && i <= n && j <= n
%         H0(i, j) = hZ(m);
%      end
     if i > 0 && j > 0 && i <= n && j <= n
%         d = norm(Z(m, :) - [Gxinitial(i) Gyinitial(j)], 2);
%         if ClosestDistanceThisEntry(i, j)==0
%             ClosestDistanceThisEntry(i, j)=d;
%             H0(i, j) = hZ(m);
%         elseif d < ClosestDistanceThisEntry(i, j)
%             ClosestDistanceThisEntry(i, j) = d;
            H0(i, j) = hZ(m);
%         end
    end
end
sample_index = find(H0 > 0);

% Matrix completion
% sample_index = find(LPR > 0);
Hc0 = myMatComplt(n, n, sample_index, H_u(sample_index));


end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Xc,A] = myMatComplt(n, m, sample_index, observed_data, noise)

if nargin < 5
    noise = 0;
end

nSamples = length(sample_index);

A = zeros(nSamples, n * m);
for i = 1:nSamples
    A(i, sample_index(i)) = 1;
end
b = observed_data(:);
b1 = b - noise .* ones(size(b));
b2 = b + noise .* ones(size(b));

% tic
cvx_begin quiet
    variable Xc(n, m)
    minimize ( norm_nuc(Xc) )
    subject to
        A * Xc(:) >= b1
        A * Xc(:) <= b2
cvx_end
% toc

end






